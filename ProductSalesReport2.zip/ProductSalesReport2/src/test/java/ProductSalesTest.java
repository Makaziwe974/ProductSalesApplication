/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Makaziwe Mtsweni
 */
public class ProductSalesTest {
 

    @Test
    public void GetSalesOverLimit_ReturnsNumberOfSales() {

        ProductSales sales = new ProductSales();

        int result = sales.GetSalesOverLimit();

        assertEquals(2, result);
    }

    @Test
    public void GetSalesUnderLimit_ReturnsNumberOfSales() {

        ProductSales sales = new ProductSales();

        int result = sales.GetSalesUnderLimit();

        assertEquals(4, result);
    }
}

