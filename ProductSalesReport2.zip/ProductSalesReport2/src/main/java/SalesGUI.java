/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Makaziwe Mtsweni
 */

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

public class SalesGUI extends JFrame {
  


    private ProductSales sales = new ProductSales();

    private JTextArea txtReport;
    private JLabel lblYears;

    public SalesGUI() {

        setTitle("Product Sales Report");
        setSize(550, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create buttons
        JButton btnLoad = new JButton("Load Product Data");
        JButton btnSave = new JButton("Save Product Data");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnLoad);
        buttonPanel.add(btnSave);

        // Create text area
        txtReport = new JTextArea();
        txtReport.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(txtReport);

        // Create years processed label
        lblYears = new JLabel("Years Processed: ");

        // Add components to the window
        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(lblYears, BorderLayout.SOUTH);

        // Button actions
        btnLoad.addActionListener(e -> loadProductData());
        btnSave.addActionListener(e -> saveProductData());

        // Create menus
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);

        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Menu actions
        exitItem.addActionListener(e -> System.exit(0));
        loadItem.addActionListener(e -> loadProductData());
        saveItem.addActionListener(e -> saveProductData());

        clearItem.addActionListener(e -> {
            txtReport.setText("");
            lblYears.setText("Years Processed: ");
        });

        setLocationRelativeTo(null);
    }

    // Load and calculate product sales
    private void loadProductData() {

        StringBuilder report = new StringBuilder();

        report.append("PRODUCT SALES REPORT\n");
        report.append("-------------------------\n");

        report.append("Total Sales: ")
              .append(sales.GetTotalSales()).append("\n");

        report.append("Average Sales: ")
              .append(String.format("%.2f", sales.GetAverageSales()))
              .append("\n");

        report.append("Sales Over Limit: ")
              .append(sales.GetSalesOverLimit()).append("\n");

        report.append("Sales Under Limit: ")
              .append(sales.GetSalesUnderLimit()).append("\n");

        txtReport.setText(report.toString());

        lblYears.setText("Years Processed: "
                + sales.GetProductsProcessed());
    }

    // Save the report to data.txt
    private void saveProductData() {

        try (FileWriter writer = new FileWriter("data.txt")) {

            writer.write(txtReport.getText());

            JOptionPane.showMessageDialog(this,
                    "Product data saved successfully.");

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this,
                    "Error saving file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new SalesGUI().setVisible(true);
        });
    }
}

    