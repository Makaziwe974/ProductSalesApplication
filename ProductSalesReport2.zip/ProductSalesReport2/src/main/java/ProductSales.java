/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Makaziwe Mtsweni
 */
public class ProductSales implements IProductSales{
    
    

    private int[][] productSales = {
        {300, 150, 700},
        {250, 200, 600}
    };

    private final int SALES_LIMIT = 500;

    @Override
    public int[][] GetProductSales() {
        return productSales;
    }

    @Override
    public int GetTotalSales() {

        int total = 0;

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {
                total += productSales[row][col];
            }
        }

        return total;
    }

    @Override
    public int GetSalesOverLimit() {

        int count = 0;

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {

                if (productSales[row][col] > SALES_LIMIT) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public int GetSalesUnderLimit() {

        int count = 0;

        for (int row = 0; row < productSales.length; row++) {
            for (int col = 0; col < productSales[row].length; col++) {

                if (productSales[row][col] < SALES_LIMIT) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public int GetProductsProcessed() {
        return productSales.length;
    }

    @Override
    public double GetAverageSales() {

        int total = GetTotalSales();

        int count = 0;

        for (int row = 0; row < productSales.length; row++) {
            count += productSales[row].length;
        }

        return (double) total / count;
    }
}

    
