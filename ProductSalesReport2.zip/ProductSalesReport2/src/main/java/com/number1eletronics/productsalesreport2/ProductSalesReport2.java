/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.number1eletronics.productsalesreport2;

/**
 *
 * @author Makaziwe Mtsweni
 */
public class ProductSalesReport2 {

    

    public static void main(String[] args) {

        // Single-dimensional array
        int[] sales = {300, 150, 700, 250, 200, 600};

        // Two-dimensional array
        int[][] productSales = {
            {300, 150, 700},
            {250, 200, 600}
        };

        System.out.println("PRODUCT SALES REPORT");

        System.out.println("Single-dimensional array:");

        for (int i = 0; i < sales.length; i++) {
            System.out.println(sales[i]);
        }

        System.out.println();

        System.out.println("Two-dimensional array:");

        for (int row = 0; row < productSales.length; row++) {

            for (int col = 0; col < productSales[row].length; col++) {

                System.out.print(productSales[row][col] + "\t");

            }

            System.out.println();
        }
    }
}
    

